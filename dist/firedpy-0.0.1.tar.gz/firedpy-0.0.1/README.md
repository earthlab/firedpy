# firedpy
A Python CLI for classifying fire events from the Collection 6 MODIS Burned Area Product.
